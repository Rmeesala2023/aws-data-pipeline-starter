import os
import csv
import io
import json
import logging
from datetime import datetime
import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client("s3")
ddb = boto3.resource("dynamodb")

TABLE_NAME = os.getenv("TABLE_NAME", "orders")
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "25"))
LOG_SAMPLE = os.getenv("LOG_SAMPLE", "true").lower() == "true"

def _validate_row(row):
    required = ["order_id", "order_date", "customer", "sku", "quantity", "price"]
    for key in required:
        if key not in row or row[key] == "":
            return False, f"Missing field: {key}"
    try:
        datetime.strptime(row["order_date"], "%Y-%m-%d")
        int(row["quantity"])
        float(row["price"])
    except Exception as e:
        return False, f"Type/format error: {e}"
    return True, ""

def _to_ddb_item(row):
    return {
        "order_id": str(row["order_id"]),
        "order_date": str(row["order_date"]),
        "customer": str(row["customer"]),
        "sku": str(row["sku"]),
        "quantity": int(row["quantity"]),
        "price": float(row["price"]),
        # Example derived field
        "amount": float(row["price"]) * int(row["quantity"]),
        "ingested_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }

def _batch_write(table, items):
    with table.batch_writer(overwrite_by_pkeys=["order_id","order_date"]) as batch:
        for it in items:
            batch.put_item(Item=it)

def lambda_handler(event, context):
    table = ddb.Table(TABLE_NAME)
    records_processed = 0
    errors = []

    logger.info("Event: %s", json.dumps(event))

    for rec in event.get("Records", []):
        if rec.get("eventSource") == "aws:s3":
            bucket = rec["s3"]["bucket"]["name"]
            key = rec["s3"]["object"]["key"]

            try:
                obj = s3.get_object(Bucket=bucket, Key=key)
                body = obj["Body"].read().decode("utf-8")
                reader = csv.DictReader(io.StringIO(body))

                batch = []
                sample = []
                for row in reader:
                    ok, reason = _validate_row(row)
                    if not ok:
                        errors.append({"row": row, "reason": reason})
                        continue
                    item = _to_ddb_item(row)
                    batch.append(item)
                    if LOG_SAMPLE and len(sample) < 3:
                        sample.append(item)

                    if len(batch) == BATCH_SIZE:
                        _batch_write(table, batch)
                        records_processed += len(batch)
                        batch = []

                if batch:
                    _batch_write(table, batch)
                    records_processed += len(batch)

                if sample:
                    logger.info("Sample rows: %s", json.dumps(sample))

            except ClientError as ce:
                logger.exception("ClientError reading S3 object: %s", ce)
                errors.append({"bucket": bucket, "key": key, "reason": str(ce)})
            except Exception as e:
                logger.exception("Unhandled error: %s", e)
                errors.append({"bucket": bucket, "key": key, "reason": str(e)})

    result = {"records_processed": records_processed, "errors": errors[:10]}
    logger.info("Result: %s", json.dumps(result))
    return result
