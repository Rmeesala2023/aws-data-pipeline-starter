# Data Pipeline with AWS (Beginner-Friendly)

**Goal:** Small cloud ETL: upload a CSV to **S3**, trigger **Lambda** to validate & transform rows, then write to **DynamoDB**. A **Glue** crawler catalogs the raw files.

## Architecture
```
S3 (raw/incoming/*.csv) ──(PUT event)──> Lambda (Python 3.11) ──> DynamoDB (orders)
                           │
                           └─> CloudWatch Logs
S3 (raw/) <─(Glue Crawler)─ Data Catalog "orders_raw"
```

## What this repo contains
- `src/lambda_function.py` — Lambda handler reading CSV from S3 and batch-writing to DynamoDB.
- `infra/template-sam.yaml` — AWS SAM template to deploy S3 bucket, DynamoDB table, and Lambda with S3 event.
- `iam_policies/lambda_execution_policy.json` — Inline policy example if deploying manually.
- `sample_data/orders_sample.csv` — Test data.
- `README` — You are here.

---

## Quick Deploy (AWS SAM)
1) **Install**: AWS CLI, AWS SAM CLI, and configure credentials.
2) In this folder run:
```bash
sam build
sam deploy --guided
```
During `--guided`, provide a unique S3 bucket name for deployment and accept defaults where unsure.

> After deploy, note the **BucketName** output. Upload CSVs to `s3://<BucketName>/raw/incoming/`.

---

## Manual Deploy (Console)
1. **DynamoDB**
   - Table: `orders`
   - PK: `order_id` (String), SK: `order_date` (String)
2. **S3**
   - Create bucket (globally unique).
   - Create folder `raw/incoming/`.
3. **Lambda**
   - Runtime: Python 3.11
   - Handler: `lambda_function.lambda_handler`
   - Env var: `TABLE_NAME=orders`
   - Role: add inline policy from `iam_policies/lambda_execution_policy.json` (edit ARNs).
4. **S3 Trigger**
   - Event: PUT, Prefix: `raw/incoming/`, Suffix: `.csv`
   - Destination: your Lambda.
5. **Glue (Optional but recommended)**
   - Create a database (e.g., `orders_db`).
   - Create a crawler to scan `s3://<bucket>/raw/` and write to `orders_db` in the Glue Data Catalog.
   - Run the crawler. Now Athena can query raw CSVs too.

---

## CSV Schema
Columns (case-sensitive):
```
order_id,order_date,customer,sku,quantity,price
```
- `order_date` must be `YYYY-MM-DD`
- `quantity` must be integer
- `price` must be float

---

## Next Ideas
- Add SQS DLQ target for failed records.
- Write to **RDS/PostgreSQL** instead of DynamoDB (requires VPC + dependency layer for drivers).
- Add AWS Glue ETL (job) to convert raw CSV -> Parquet in `s3://<bucket>/curated/`.

Good luck, and have fun building! 🚀
