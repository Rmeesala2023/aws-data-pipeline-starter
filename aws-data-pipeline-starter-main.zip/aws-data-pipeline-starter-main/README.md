# aws-data-pipeline-starter
 Beginner-friendly AWS S3 → Lambda → DynamoDB ETL project
